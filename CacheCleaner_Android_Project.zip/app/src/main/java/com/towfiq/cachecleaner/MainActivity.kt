package com.towfiq.cachecleaner

import android.app.AppOpsManager
import android.app.usage.StorageStatsManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.os.storage.StorageManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ---------- data ----------
data class AppCache(val pkg: String, val name: String, val cache: Long)
data class Stor(val total: Long, val free: Long, val apps: Long, val cache: Long)

fun hasUsage(c: Context): Boolean {
    val a = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
    val m = if (Build.VERSION.SDK_INT >= 29)
        a.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
    else @Suppress("DEPRECATION") a.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
    return m == AppOpsManager.MODE_ALLOWED
}

fun scan(c: Context): Pair<Stor, List<AppCache>> {
    val ssm = c.getSystemService(StorageStatsManager::class.java)
    val pm = c.packageManager
    val id = StorageManager.UUID_DEFAULT
    var appsB = 0L; var cacheB = 0L
    val list = mutableListOf<AppCache>()
    for (ai in pm.getInstalledApplications(0)) {
        try {
            val s = ssm.queryStatsForPackage(id, ai.packageName, Process.myUserHandle())
            appsB += s.appBytes + s.dataBytes - s.cacheBytes
            cacheB += s.cacheBytes
            if (s.cacheBytes > 0) list += AppCache(ai.packageName, pm.getApplicationLabel(ai).toString(), s.cacheBytes)
        } catch (_: Exception) {}
    }
    return Stor(ssm.getTotalBytes(id), ssm.getFreeBytes(id), appsB, cacheB) to list.sortedByDescending { it.cache }
}

fun fmtP(b: Long): Pair<String, String> {
    val mb = b / 1048576.0
    return if (mb >= 1024) "%.2f".format(mb / 1024) to "GB" else "%.0f".format(mb) to "MB"
}
fun fmt(b: Long) = fmtP(b).let { "${it.first} ${it.second}" }

// ---------- look ----------
class Pal(val bg: Color, val panel: Color, val line: Color, val text: Color, val mute: Color)
val Accent = Color(0xFFB3363F)
val Accent2 = Color(0xFF5E1220)
val DarkP = Pal(Color(0xFF0E0807), Color(0xFF1B110E), Color(0xFF2F1E19), Color(0xFFF4ECE8), Color(0xFFA08D84))
val LightP = Pal(Color(0xFFF7F0EA), Color(0xFFFFFAF6), Color(0xFFE8DBD1), Color(0xFF2B1713), Color(0xFF7D6A62))

val S = mapOf(
    "en" to mapOf("clean" to "CLEAN", "can" to "cache can be cleared", "all" to "all clean", "home" to "Home", "apps" to "Apps",
        "storage" to "Storage", "cba" to "Cache by app", "details" to "Storage details", "an" to "Analyze",
        "language" to "Language", "dark" to "Dark mode", "about" to "About", "version" to "Version", "contact" to "Contact",
        "mobile" to "Mobile", "usage" to "Allow usage access so the app can read each app's cache size.", "allow" to "Allow access",
        "Apps" to "Apps", "Cache" to "Cache", "Other" to "Other", "Free" to "Free",
        "hint" to "Clean opens each selected app's storage page. Tap Storage, then Clear cache, then go back."),
    "bn" to mapOf("clean" to "পরিষ্কার করুন", "can" to "ক্যাশ পরিষ্কার করা যাবে", "all" to "সব পরিষ্কার", "home" to "হোম", "apps" to "অ্যাপস",
        "storage" to "স্টোরেজ", "cba" to "অ্যাপ অনুযায়ী ক্যাশ", "details" to "স্টোরেজ বিস্তারিত", "an" to "বিশ্লেষণ",
        "language" to "ভাষা", "dark" to "ডার্ক মোড", "about" to "সম্পর্কে", "version" to "ভার্সন", "contact" to "যোগাযোগ",
        "mobile" to "মোবাইল", "usage" to "প্রতিটি অ্যাপের ক্যাশ সাইজ দেখতে ইউসেজ অ্যাক্সেস দিন।", "allow" to "অ্যাক্সেস দিন",
        "Apps" to "অ্যাপস", "Cache" to "ক্যাশ", "Other" to "অন্যান্য", "Free" to "ফাঁকা",
        "hint" to "Clean চাপলে নির্বাচিত অ্যাপের স্টোরেজ পেজ খুলবে। Storage চাপুন, তারপর Clear cache, তারপর ব্যাক করুন।")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App(this) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(act: ComponentActivity) {
    val prefs = remember { act.getSharedPreferences("cc", 0) }
    var dark by remember { mutableStateOf(prefs.getBoolean("dark", true)) }
    var lang by remember { mutableStateOf(prefs.getString("lang", "en")!!) }
    val p = if (dark) DarkP else LightP
    fun t(k: String) = S[lang]?.get(k) ?: k

    var stats by remember { mutableStateOf<Stor?>(null) }
    var apps by remember { mutableStateOf(listOf<AppCache>()) }
    val selected = remember { mutableStateListOf<String>() }
    var perm by remember { mutableStateOf(hasUsage(act)) }
    var tab by remember { mutableIntStateOf(0) }
    var aboutOpen by remember { mutableStateOf(false) }
    val pending = remember { mutableStateListOf<String>() }
    val scope = rememberCoroutineScope()
    val drawer = rememberDrawerState(DrawerValue.Closed)

    fun rescan() {
        perm = hasUsage(act)
        if (!perm) return
        scope.launch {
            val r = withContext(Dispatchers.IO) { scan(act) }
            stats = r.first; apps = r.second
            selected.clear(); selected.addAll(r.second.map { it.pkg })
        }
    }
    fun openNext() {
        val pk = pending.removeAt(0)
        act.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pk")))
    }
    DisposableEffect(Unit) {
        val o = object : DefaultLifecycleObserver {
            override fun onResume(owner: LifecycleOwner) { if (pending.isNotEmpty()) openNext() else rescan() }
        }
        act.lifecycle.addObserver(o)
        onDispose { act.lifecycle.removeObserver(o) }
    }

    val cacheSel = apps.filter { it.pkg in selected }.sumOf { it.cache }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = p.panel) {
                Column(Modifier.fillMaxHeight().padding(vertical = 20.dp)) {
                    Text("Cache Cleaner", color = p.text, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(horizontal = 22.dp, vertical = 12.dp))
                    HorizontalDivider(color = p.line)
                    Row(Modifier.fillMaxWidth().padding(22.dp, 14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(t("language"), color = p.text, fontSize = 16.sp, modifier = Modifier.weight(1f))
                        listOf("en" to "EN", "bn" to "বাংলা").forEach { (k, label) ->
                            Box(Modifier.padding(start = 6.dp).clip(CircleShape)
                                .background(if (lang == k) Accent else Color.Transparent)
                                .border(1.dp, if (lang == k) Accent else p.line, CircleShape)
                                .clickable { lang = k; prefs.edit().putString("lang", k).apply() }
                                .padding(12.dp, 6.dp)) { Text(label, color = if (lang == k) Color.White else p.mute, fontSize = 13.sp) }
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(22.dp, 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(t("dark"), color = p.text, fontSize = 16.sp, modifier = Modifier.weight(1f))
                        Switch(checked = dark, onCheckedChange = { dark = it; prefs.edit().putBoolean("dark", it).apply() },
                            colors = SwitchDefaults.colors(checkedTrackColor = Accent, checkedThumbColor = Color.White))
                    }
                    Row(Modifier.fillMaxWidth().clickable { aboutOpen = !aboutOpen }.padding(22.dp, 16.dp)) {
                        Text(t("about"), color = p.text, fontSize = 16.sp, modifier = Modifier.weight(1f))
                        Text(if (aboutOpen) "−" else "+", color = p.mute, fontSize = 20.sp)
                    }
                    if (aboutOpen) Column(Modifier.padding(horizontal = 22.dp)) {
                        Text("Towfiq Rahman", color = p.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                        Text("${t("contact")}: tr.towfiqr@gmail.com", color = p.mute, fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp))
                        Text("${t("mobile")}: +8801645424280", color = p.mute, fontSize = 14.sp)
                    }
                    Spacer(Modifier.weight(1f))
                    HorizontalDivider(color = p.line)
                    Text("${t("version")} 02.000.26", color = p.mute, fontSize = 13.sp, modifier = Modifier.padding(22.dp, 14.dp))
                }
            }
        }
    ) {
        Scaffold(
            containerColor = p.bg,
            topBar = {
                Row(Modifier.fillMaxWidth().statusBarsPadding().padding(18.dp, 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(p.panel).border(1.dp, p.line, RoundedCornerShape(12.dp))
                        .clickable { scope.launch { drawer.open() } }, contentAlignment = Alignment.Center) {
                        Text("≡", color = p.text, fontSize = 24.sp)
                    }
                    Text("Cache Cleaner", color = p.text, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                    Spacer(Modifier.width(42.dp))
                }
            },
            bottomBar = {
                Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(18.dp, 8.dp).clip(CircleShape).background(p.panel).border(1.dp, p.line, CircleShape).padding(6.dp)) {
                    listOf("home", "apps").forEachIndexed { i, k ->
                        Box(Modifier.weight(1f).clip(CircleShape).background(if (tab == i) Accent else Color.Transparent).clickable { tab = i }.padding(12.dp), contentAlignment = Alignment.Center) {
                            Text(t(k), color = if (tab == i) Color.White else p.mute, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                    }
                }
            }
        ) { pad ->
            Column(Modifier.padding(pad).fillMaxSize()) {
                if (!perm) Column(Modifier.fillMaxWidth().padding(18.dp).clip(RoundedCornerShape(16.dp)).background(p.panel).border(1.dp, p.line, RoundedCornerShape(16.dp)).padding(18.dp)) {
                    Text(t("usage"), color = p.text, fontSize = 15.sp)
                    Spacer(Modifier.height(12.dp))
                    Box(Modifier.clip(RoundedCornerShape(12.dp)).background(Accent).clickable { act.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }.padding(18.dp, 10.dp)) {
                        Text(t("allow"), color = Color.White, fontWeight = FontWeight.Bold)
                    }
                } else if (tab == 0) {
                    val st = stats
                    val prog by animateFloatAsState((cacheSel / 1.5e9f).coerceIn(0f, 1f), label = "ring")
                    val (num, unit) = fmtP(cacheSel)
                    Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)) {
                        Box(Modifier.padding(top = 12.dp).size(250.dp).align(Alignment.CenterHorizontally), contentAlignment = Alignment.Center) {
                            Canvas(Modifier.fillMaxSize()) {
                                val sw = 22.dp.toPx(); val d = size.minDimension - sw; val tl = Offset(sw / 2, sw / 2)
                                drawArc(p.line, -90f, 360f, false, tl, Size(d, d), style = Stroke(sw, cap = StrokeCap.Round))
                                drawArc(Brush.linearGradient(listOf(Color(0xFFD09468), Accent)), -90f, 360f * prog, false, tl, Size(d, d), style = Stroke(sw, cap = StrokeCap.Round))
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Row(verticalAlignment = Alignment.Bottom) {
                                    Text(num, color = p.text, fontSize = 64.sp, fontWeight = FontWeight.ExtraBold)
                                    Text(unit, color = Accent, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp, bottom = 10.dp))
                                }
                                Text(if (cacheSel == 0L) t("all") else t("can"), color = p.mute, fontSize = 14.sp)
                            }
                        }
                        Spacer(Modifier.height(14.dp))
                        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Brush.linearGradient(listOf(Accent, Accent2)))
                            .clickable(enabled = selected.isNotEmpty()) { pending.clear(); pending.addAll(selected); openNext() }.padding(18.dp), contentAlignment = Alignment.Center) {
                            Text("${t("clean")}  ${fmt(cacheSel)}", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                        }
                        Text(t("hint"), color = p.mute, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
                        if (st != null) {
                            Text(t("storage"), color = p.text, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 24.dp, bottom = 12.dp))
                            val used = st.total - st.free
                            val other = (used - st.apps - st.cache).coerceAtLeast(0)
                            val segs = listOf(Triple("Apps", st.apps, Accent), Triple("Cache", st.cache, Color(0xFFE6C19A)), Triple("Other", other, Color(0xFF6B524A)), Triple("Free", st.free, p.line))
                            Row(Modifier.fillMaxWidth().height(16.dp).clip(RoundedCornerShape(8.dp))) {
                                segs.forEach { (_, v, c) -> Box(Modifier.weight((v.toFloat() / st.total).coerceAtLeast(0.005f)).fillMaxHeight().background(c)) }
                            }
                            Spacer(Modifier.height(14.dp))
                            segs.chunked(2).forEach { row ->
                                Row(Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
                                    row.forEach { (k, v, c) ->
                                        Row(Modifier.weight(1f)) {
                                            Box(Modifier.padding(top = 6.dp).size(10.dp).clip(RoundedCornerShape(3.dp)).background(c))
                                            Column(Modifier.padding(start = 10.dp)) {
                                                Text(fmt(v), color = p.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                                Text(t(k), color = p.mute, fontSize = 13.sp)
                                            }
                                        }
                                    }
                                }
                            }
                            Text("${fmt(st.total)} total  ·  ${fmt(used)} used", color = p.mute, fontSize = 13.sp)
                        }
                        Row(Modifier.padding(vertical = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            listOf(t("details") to { tab = 1 }, t("an") to { rescan() }).forEach { (label, act2) ->
                                Box(Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(p.panel).border(1.dp, p.line, RoundedCornerShape(14.dp)).clickable { act2() }.padding(16.dp)) {
                                    Text(label, color = p.text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                }
                            }
                        }
                    }
                } else {
                    Text(t("cba"), color = p.text, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(18.dp, 8.dp))
                    val max = (apps.firstOrNull()?.cache ?: 1L).toFloat()
                    LazyColumn(Modifier.padding(horizontal = 18.dp).clip(RoundedCornerShape(16.dp)).background(p.panel)) {
                        items(apps, key = { it.pkg }) { a ->
                            val icon = remember(a.pkg) { runCatching { act.packageManager.getApplicationIcon(a.pkg).toBitmap(96, 96).asImageBitmap() }.getOrNull() }
                            val on = a.pkg in selected
                            Row(Modifier.fillMaxWidth().clickable { if (on) selected.remove(a.pkg) else selected.add(a.pkg) }.padding(14.dp, 12.dp), verticalAlignment = Alignment.CenterVertically) {
                                if (icon != null) Image(icon, null, Modifier.size(40.dp).clip(RoundedCornerShape(10.dp)))
                                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                                    Text(a.name, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                    Box(Modifier.padding(top = 6.dp).fillMaxWidth().height(4.dp).clip(CircleShape).background(p.line)) {
                                        Box(Modifier.fillMaxWidth(a.cache / max).fillMaxHeight().background(Accent))
                                    }
                                }
                                Text(fmt(a.cache), color = p.text, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                Box(Modifier.padding(start = 12.dp).size(22.dp).clip(RoundedCornerShape(7.dp)).background(if (on) Accent else Color.Transparent)
                                    .border(2.dp, if (on) Accent else p.mute, RoundedCornerShape(7.dp)), contentAlignment = Alignment.Center) {
                                    if (on) Text("✓", color = Color.White, fontSize = 14.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
