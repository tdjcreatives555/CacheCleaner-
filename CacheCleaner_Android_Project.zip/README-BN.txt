Cache Cleaner Android Project
==============================

এই ZIP-এ আপনার MainActivity.kt-কে একটি Android project-এর মধ্যে রাখা হয়েছে।
AndroidIDE ব্যবহার না করেও GitHub Actions দিয়ে অনলাইনে APK build করার জন্য workflow দেওয়া আছে।

ফোন থেকে build করার সংক্ষিপ্ত পদ্ধতি:
1. ZIP extract করুন (Files app বা ZArchiver দিয়ে)।
2. GitHub-এ নতুন repository তৈরি করুন, নাম দিন CacheCleaner।
3. ZIP-এর ভেতরের ফাইল ও ফোল্ডারগুলো repository-র root-এ upload করুন; ZIP ফাইলটিকে একা upload করবেন না।
4. Upload শেষে repository-তে Actions tab খুলুন।
5. "Build Cache Cleaner APK" workflow নির্বাচন করে "Run workflow" চাপুন (অথবা main branch-এ push হলে build শুরু হবে)।
6. Build শেষ হলে workflow run খুলুন। নিচের Artifacts অংশ থেকে CacheCleaner-debug-apk ডাউনলোড করুন।
7. ZIP artifact extract করে app-debug.apk ইনস্টল করুন।

মনে রাখবেন:
- GitHub account প্রয়োজন।
- GitHub Actions-এ প্রথম build-এ কয়েক মিনিট লাগতে পারে।
- Build ব্যর্থ হলে Actions run-এর error log দেখে সংশোধন করতে হবে।
- APK debug build; এটি সরাসরি ফোনে ইনস্টল করার জন্য।
- Cache Cleaner অন্য অ্যাপের cache নিজে থেকে নীরবে clear করতে পারে না; Android-এর app storage settings খুলে ব্যবহারকারীকে Clear cache চাপতে হয়।
- QUERY_ALL_PACKAGES permission সংবেদনশীল; অ্যাপ প্রকাশ করার আগে Google Play policy পরীক্ষা করুন।
